Lab 5
====

Lab 5: Putting it together
